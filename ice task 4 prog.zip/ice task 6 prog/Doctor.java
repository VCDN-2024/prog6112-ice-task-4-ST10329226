/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package doctor;

public class Doctor extends HospitalStaff {

    private boolean isSpecialist;

    public Doctor() {
        super();
    }

    public Doctor(String firstName, String lastName, String streetAddress, String zipCode, String phoneNumber,
                   int staffID, double annualSalary, String departmentName, boolean isSpecialist) {
        super(firstName, lastName, streetAddress, zipCode, phoneNumber, staffID, annualSalary, departmentName);
        this.isSpecialist = isSpecialist;
    }

    // Getter and setter for isSpecialist

    public boolean isSpecialist() {
        return isSpecialist;
    }

    public void setSpecialist(boolean specialist) {
        isSpecialist = specialist;
    }

    @Override
    public void setDataFromDialog() {
        super.setDataFromDialog