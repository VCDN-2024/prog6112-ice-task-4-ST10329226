/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hospitalstaff;

import person.Person;

public class HospitalStaff extends Person {

    private int staffID;
    private double annualSalary;
    private String departmentName;

    // Constructors
    public HospitalStaff() {
        super(); // Call the parent class constructor
    }

    public HospitalStaff(String firstName, String lastName, String streetAddress, String zipCode, String phoneNumber,
                         int staffID, double annualSalary, String departmentName) {
        super(firstName, lastName, streetAddress, zipCode, phoneNumber);
        this.staffID = staffID;
        this.annualSalary = annualSalary;
        this.departmentName = departmentName;
    }

    // Getters and setters
    public int getStaffID() {
        return staffID;
    }

    public void setStaffID(int staffID) {
        this.staffID = staffID;
    }

    public double getAnnualSalary() {
        return annualSalary;
    }

    public void setAnnualSalary(double annualSalary) {
        this.annualSalary = annualSalary;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    // Overridden methods
    @Override
    public void setDataFromDialog() {
        super.setDataFromDialog(); // Get basic person information from the parent class

        // Get additional hospital staff information from dialog boxes
        staffID = Integer.parseInt(JOptionPane.showInputDialog("Enter staff ID:"));
        annualSalary = Double.parseDouble(JOptionPane.showInputDialog("Enter annual salary:"));
        departmentName = JOptionPane.showInputDialog("Enter department name:");
    }

    @Override
    public String displayData() {
        return String.format("%s, Staff ID: %d, Salary: %.2f, Department: %s", super.displayData(), staffID, annualSalary, departmentName);
    }
}